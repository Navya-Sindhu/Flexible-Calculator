package com.calculator;

import com.calculator.operations.AddOperation;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {
    @Test
    public void testBasicOperations() {
        Calculator calculator = new Calculator();
        assertEquals(new BigDecimal("5"), calculator.calculate(Operation.ADD, new BigDecimal("2"), new BigDecimal("3")));
        assertEquals(new BigDecimal("-1"), calculator.calculate(Operation.SUBTRACT, new BigDecimal("2"), new BigDecimal("3")));
        assertEquals(new BigDecimal("6"), calculator.calculate(Operation.MULTIPLY, new BigDecimal("2"), new BigDecimal("3")));
        assertEquals(new BigDecimal("2"), calculator.calculate(Operation.DIVIDE, new BigDecimal("6"), new BigDecimal("3")));
    }

    @Test
    public void testChainingOperations() {
        Calculator calculator = new Calculator();
        BigDecimal initial = new BigDecimal("5");
        Operation[] ops = {Operation.ADD, Operation.MULTIPLY};
        BigDecimal[] nums = {new BigDecimal("3"), new BigDecimal("2")};
        assertEquals(new BigDecimal("16"), calculator.chainOperations(initial, ops, nums));
    }

    @Test
    public void testInvalidOperation() {
        Calculator calculator = new Calculator();
        Exception exception = assertThrows(RuntimeException.class, () -> {
            calculator.calculate(null, new BigDecimal("5"), new BigDecimal("5"));
        });
        assertTrue(exception.getMessage().contains("Unsupported operation"));
    }
}
