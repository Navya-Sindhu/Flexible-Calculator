package com.calculator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Flexible Calculator!");

        while (true) {
            System.out.println("Choose operation mode: Single (1) or Chaining (2):");
            String mode = scanner.nextLine();

            if (mode.equals("1")) {
                runSingleOperationMode(calculator, scanner);
            } else if (mode.equals("2")) {
                runChainingMode(calculator, scanner);
            } else {
                System.out.println("Invalid mode. Please choose either '1' or '2'.");
                continue;
            }

            System.out.println("Do you want to perform another calculation? (yes/no):");
            String choice = scanner.nextLine().toLowerCase();
            if (!choice.equals("yes")) {
                break;
            }
        }

        System.out.println("Thank you for using the Flexible Calculator!");
        scanner.close();
    }

    private static void runSingleOperationMode(Calculator calculator, Scanner scanner) {
        System.out.println("Enter the first number:");
        BigDecimal num1 = new BigDecimal(scanner.nextLine());

        System.out.println("Enter the operation (ADD, SUBTRACT, MULTIPLY, DIVIDE):");
        String operationInput = scanner.nextLine().toUpperCase();

        Operation operation;
        try {
            operation = Operation.valueOf(operationInput);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid operation. Please try again.");
            return;
        }

        System.out.println("Enter the second number:");
        BigDecimal num2 = new BigDecimal(scanner.nextLine());

        try {
            BigDecimal result = calculator.calculate(operation, num1, num2);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    private static void runChainingMode(Calculator calculator, Scanner scanner) {
        System.out.println("Enter the initial number:");
        BigDecimal initialValue = new BigDecimal(scanner.nextLine());

        List<Operation> operations = new ArrayList<>();
        List<BigDecimal> numbers = new ArrayList<>();

        while (true) {
            System.out.println("Enter the next operation (ADD, SUBTRACT, MULTIPLY, DIVIDE) or 'done' to finish:");
            String operationInput = scanner.nextLine().toUpperCase();
            if (operationInput.equals("DONE")) {
                break;
            }

            Operation operation;
            try {
                operation = Operation.valueOf(operationInput);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid operation. Please try again.");
                continue;
            }

            operations.add(operation);

            System.out.println("Enter the next number:");
            BigDecimal number = new BigDecimal(scanner.nextLine());
            numbers.add(number);
        }

        try {
            BigDecimal result = calculator.chainOperations(initialValue, operations.toArray(new Operation[0]), numbers.toArray(new BigDecimal[0]));
            System.out.println("Final result after chaining operations: " + result);
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }
}