package com.calculator;

import com.calculator.operations.*;
import com.calculator.exceptions.InvalidOperationException;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class Calculator {
    private final Map<Operation, CalculatorOperation> operationsMap = new HashMap<>();

    public Calculator() {
        // Register default operations
        operationsMap.put(Operation.ADD, new AddOperation());
        operationsMap.put(Operation.SUBTRACT, new SubtractOperation());
        operationsMap.put(Operation.MULTIPLY, new MultiplyOperation());
        operationsMap.put(Operation.DIVIDE, new DivideOperation());
    }

    public BigDecimal calculate(Operation op, BigDecimal num1, BigDecimal num2) {
        CalculatorOperation operation = operationsMap.get(op);
        if (operation == null) {
            throw new InvalidOperationException("Unsupported operation: " + op);
        }
        return operation.calculate(num1, num2);
    }

    public void addOperation(Operation op, CalculatorOperation calculatorOperation) {
        operationsMap.put(op, calculatorOperation);
    }

    public BigDecimal chainOperations(BigDecimal initialValue, Operation[] operations, BigDecimal[] numbers) {
        BigDecimal result = initialValue;
        for (int i = 0; i < operations.length; i++) {
            result = calculate(operations[i], result, numbers[i]);
        }
        return result;
    }
}
