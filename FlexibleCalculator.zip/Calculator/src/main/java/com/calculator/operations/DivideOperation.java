package com.calculator.operations;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DivideOperation implements CalculatorOperation {
    @Override
    public BigDecimal calculate(BigDecimal num1, BigDecimal num2) {
        if (num2.compareTo(BigDecimal.ZERO) == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return num1.divide(num2, 3, RoundingMode.HALF_UP);
    }
}
