package com.calculator.operations;

import java.math.BigDecimal;

public interface CalculatorOperation {
    BigDecimal calculate(BigDecimal num1, BigDecimal num2);
}
