package com.calculator.operations;

import java.math.BigDecimal;

public class AddOperation implements CalculatorOperation {
    @Override
    public BigDecimal calculate(BigDecimal num1, BigDecimal num2) {
        return num1.add(num2);
    }
}
